//
//  CodingChallengeApp.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import SwiftUI

@main
struct CodingChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }//Window
    }//VARBODY
}//STRUCT
