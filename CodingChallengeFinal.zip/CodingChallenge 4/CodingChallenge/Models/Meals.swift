//
//  Meals.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import Foundation

struct Meals: Decodable {
    let mealName: String
    let idNumber: String
    let url: String
    
    private enum CodingKeys: String, CodingKey {
        case mealName = "strMeal"
        case idNumber = "idMeal"
        case url = "strMealThumb"
    }//PRIVATE
}//STRUCTMEAL

struct Response: Decodable {
    let meals: [Meals]
}//STRUCTRESPONSE

struct MealDetail: Decodable {
    let idNumber: String
    let mealName: String
    let strCategory: String
    let instructions: String
    let ingredients: [String]
    let url: String // New property for image URL
    
    private enum CodingKeys: String, CodingKey {
        case idNumber = "idMeal", mealName = "strMeal", strCategory, instructions = "strInstructions", strMealThumb
        // Include all strIngredient(n) keys
        case strIngredient1, strIngredient2, strIngredient3, strIngredient4, strIngredient5,
             strIngredient6, strIngredient7, strIngredient8, strIngredient9, strIngredient10,
             strIngredient11, strIngredient12, strIngredient13, strIngredient14, strIngredient15,
             strIngredient16, strIngredient17, strIngredient18, strIngredient19, strIngredient20
    }//PRIVATE
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        idNumber = try container.decode(String.self, forKey: .idNumber)
        mealName = try container.decode(String.self, forKey: .mealName)
        strCategory = try container.decode(String.self, forKey: .strCategory)
        instructions = try container.decode(String.self, forKey: .instructions)
        
        url = try container.decode(String.self, forKey: .strMealThumb) // Save image URL
        
        var ingredientsArray = [String]()
        for i in 1...20 {
            let ingredientKey = CodingKeys(stringValue: "strIngredient\(i)")!
            if let ingredient = try? container.decodeIfPresent(String.self, forKey: ingredientKey), !ingredient.isEmpty {
                ingredientsArray.append(ingredient)
            }//IF
        }//FOR
        ingredients = ingredientsArray
    }//INIT
}//STRUCTMEALDETAIL


struct MealDetailResponse: Decodable {
    let meals: [MealDetail]
}//STRUCTMEALDEYTAILRESPONSE
