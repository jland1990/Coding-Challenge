//
//  MealsListViewModel.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import Foundation

class MealsListViewModel: ObservableObject {
    
    @Published var meals: [MealsViewModel] = []
    
    func getMeals() async {
        
        do {
            var meals = try await WebService().fetchMeals(url: Constants.Urls.dessertsUrl)
            meals.sort {$0.mealName.localizedStandardCompare($1.mealName) == .orderedAscending
            }//var
            
            self.meals = meals.map(MealsViewModel.init)
        }//DO
        catch {
            print("error")
        }//CATCH
    }//FUNC
}//CLASS
