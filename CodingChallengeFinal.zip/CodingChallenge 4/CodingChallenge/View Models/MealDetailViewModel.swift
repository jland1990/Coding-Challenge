//
//  MealDetailViewModel.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/5/23.
//

import Foundation

class MealDetailViewModel: ObservableObject {
    @Published var meal: MealDetail?
    
    func getMealDetail(id: String) async {
        do {
            meal = try await WebService().fetchMealDetail(id: id)
        } catch {
            print("Failed to fetch meal detail: \(error)")
        }//CATCH
    }//FUNC
}//CLASS
