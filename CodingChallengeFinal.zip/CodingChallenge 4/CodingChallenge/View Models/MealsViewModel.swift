//
//  MealsViewModel.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import Foundation

struct MealsViewModel {
    var meal: Meals
    
    var mealName: String {
        return meal.mealName
    }//VAR MEAL
    
    var idNumber: String {
        return meal.idNumber
    }//VAR ID
    
    var url: String {
        return meal.url
    }//VAR URL
    
    static var `default`: MealsViewModel {
        let meal = Meals(mealName: "Sticky Toffee Pudding", idNumber: "52883", url: "https://www.potus.com/wp-content/uploads/2018/08/01_george_washington_1_gallery.jpg")
        return MealsViewModel(meal: meal)
    }//DEFAULT VIEW
}//STRUCT
