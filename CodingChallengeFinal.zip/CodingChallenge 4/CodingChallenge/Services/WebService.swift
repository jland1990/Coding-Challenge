//
//  WebService.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import Foundation

class WebService {
    func fetchMeals(url: URL?) async throws -> [Meals] {
        
        guard let url = url else {
            return []
        }//GUARD
        let (data, _) = try await URLSession.shared.data(from: url)
        let response = try? JSONDecoder().decode(Response.self, from: data)
        
        return response?.meals ?? []
    }//FETCHMEALS
    
    func fetchMealDetail(id: String) async throws -> MealDetail? {
            let url = URL(string: "https://themealdb.com/api/json/v1/1/lookup.php?i=\(id)")
            let (data, _) = try await URLSession.shared.data(from: url!)
            let response = try? JSONDecoder().decode(MealDetailResponse.self, from: data)
            return response?.meals.first
        }//FETCHMEALDETAIL
    
}//CLASS
