//
//  Constants.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import Foundation

struct Constants {
    
    struct Urls {
        static let dessertsUrl: URL? = URL(string: "https://themealdb.com/api/json/v1/1/filter.php?c=Dessert")
        
        static let mealsURL: URL? = URL(string: "https://themealdb.com/api/json/v1/1/lookup.php?i=MEAL_ID")
    }//STRUCTURLS
}//STRUCTCONTANTS
