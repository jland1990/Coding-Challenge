//
//  DessertDetail.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import SwiftUI

struct DessertDetail: View {
    @StateObject var detailVM = MealDetailViewModel()
    var mealId: String
    
    var body: some View {
        ScrollView {
            VStack {
                if let meal = detailVM.meal {
                    Text(meal.mealName)
                        .bold()
                    
                    Spacer()
                    
                    AsyncImage(url: URL(string: meal.url)){ image in image.resizable()
                            .scaledToFit()
                            .cornerRadius(6)
                    } placeholder: {
                        ProgressView()
                    }
                    .padding(.horizontal)
                    
                    Spacer()
                    
                    Text("Ingredients:")
                        .font(.headline)
                        .bold()
                    
                    ForEach(meal.ingredients, id: \.self) { ingredient in
                        Text("-\(ingredient)")
                    }
                    .padding(.vertical)
                    
                    Spacer()
                    
                    Text("Instrucations")
                        .bold()
                    
                    Text(meal.instructions)
                    
                } else {
                    Text("Loading...")
                }
            }//VSTACK
        }//SCROLLVIEW
        .task {
            await detailVM.getMealDetail(id: mealId)
        }
    }//VARBODY
}//STRUCT
struct DessertDetail_Previews: PreviewProvider {
    static var previews: some View {
        DessertDetail(mealId: "52883")
            .previewLayout(.sizeThatFits)
    }//STATIC VAR
}//STRUCT DESSERTDETAIL PREVIEW

