//
//  ContentView.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import SwiftUI

struct ContentView: View {
    
    @ObservedObject private var mealsListVM = MealsListViewModel()
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(mealsListVM.meals, id: \.mealName) { mealVM in
                    NavigationLink(destination: DessertDetail(mealId: mealVM.idNumber)) {
                        DessertCell(meal: mealVM)
                    }//NAV
                }//FOREACH
            }//LIST
            .listStyle(.plain)
            .navigationTitle("Desserts")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                await mealsListVM.getMeals()
            }
        }//NAVIGATIONSTACK
    }//BODY
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }//STATIC VAR
}//STRUCT CONENTVIEW PREVIEW
