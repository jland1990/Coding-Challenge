//
//  DessertCell.swift
//  CodingChallenge
//
//  Created by Jessica Landmeier on 8/4/23.
//

import SwiftUI

struct DessertCell: View {
    
    var meal: MealsViewModel
    
    var body: some View {
        HStack {
            AsyncImage(url: URL(string: meal.url)) {
                image in image.resizable().cornerRadius(6)
            } placeholder: {
                ProgressView()
            }
            .frame(width: 50, height: 50)
            
            VStack(alignment: .leading){
                Text(meal.mealName)
                    .font(.headline)
                    .bold()
                  
            }//VSTACK
        }//HSTACK
    }//BODY
}//STRUCT DESSERTCELL

struct DessertCell_Previews: PreviewProvider {
    static var previews: some View {
        DessertCell(meal: MealsViewModel.default)
            .previewLayout(.sizeThatFits)
    }//STATIC VAR
}//STRUCT DESSERTCELL PREVIEWS

